#ifndef FILE_READER_H
#define FILE_READER_H

#include "rates_structures.h"

void read(const char* file_name, rates* array[], int& size);

#endif