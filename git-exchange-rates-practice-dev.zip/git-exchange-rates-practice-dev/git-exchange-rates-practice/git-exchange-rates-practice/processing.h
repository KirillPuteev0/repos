
#include <iostream>
#include "rates_structures.h"
using namespace std;
void Difference(rates* subscribtions[], int size);
